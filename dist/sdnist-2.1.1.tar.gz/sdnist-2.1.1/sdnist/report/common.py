from pathlib import Path

FILE_DIR = Path(__file__).parent
REPORTS_DIR = Path(Path().cwd(), 'reports')
